Application Name
================
ftp_client


Application Version
===================
2.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This application demonstrates sending a file to an FTP server
using ftplib.py. Server speedtest.tele2.net is used as an example


Expected Output
===============
A file is sent to an FTP server speedtest.tele2.net.

