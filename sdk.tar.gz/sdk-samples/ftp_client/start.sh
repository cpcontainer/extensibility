#!/bin/bash
cppython ftp_client.py