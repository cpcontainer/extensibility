#!/bin/bash
cppython ftp_server.py &
cppython Mobile_Site_Survey.py
