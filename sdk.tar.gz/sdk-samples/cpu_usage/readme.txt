Application Name
================
cpu_usage


Application Version
===================
1.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This application writes a .csv file of CPU usage


Expected Output
===============
CSV file

