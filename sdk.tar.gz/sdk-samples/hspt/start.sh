#!/bin/bash
cppython hspt.py
