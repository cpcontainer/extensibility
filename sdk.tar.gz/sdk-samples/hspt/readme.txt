Application Name
================
hspt


Application Version
===================
2.0


NCOS Devices Supported
======================
Only WiFi enabled devices.


External Requirements
=====================
None


Application Purpose
===================
This application demonstrate how to enable and disable a custom
HotSpot splash page. For specific details, see file dynui.txt in
the application directory.


Expected Output
===============
A user that connects to the device HotSpot should be presented
with a custom splash page.

