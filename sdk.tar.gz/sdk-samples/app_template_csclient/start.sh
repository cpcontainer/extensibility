#!/bin/bash
cppython app_template_csclient.py