Application Name
================
cp_shell


Application Version
===================
0.1


NCOS Devices Supported
======================
All


External Requirements
=====================
None


Application Purpose
===================
Runs a web UI on port 8022 providing interactive interface to the linux shell.
Like bash in a browser.