#!/bin/bash
cppython cli_sample.py start
