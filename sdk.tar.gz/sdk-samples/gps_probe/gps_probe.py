# ---
# jupyter:
#   jupytext:
#     cell_metadata_filter: -all
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.5
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

"""
Probe the GPS hardware and log the results.
"""
from csclient import EventingCSClient

cp = EventingCSClient('gps_probe')

gps_enabled = cp.get('/config/system/gps/enabled')

if not gps_enabled:
    cp.log('GPS Function is NOT Enabled')
else:
    cp.log('GPS Function is Enabled')
    gps_data = cp.get('/status/gps')
    cp.log(gps_data)
