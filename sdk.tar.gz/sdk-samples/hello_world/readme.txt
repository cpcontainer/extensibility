Application Name
================
hello_world


Application Version
===================
1.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
Simple app to write a log


Expected Output
===============
Info level log message: "Hello World!"

