pip install ipcalc
ipython "container_lan.ipynb"
ipython "get_ip_address.ipynb"
ipython "samples2notebooks.ipynb" &
ipython "SDK Container.ipynb" &
